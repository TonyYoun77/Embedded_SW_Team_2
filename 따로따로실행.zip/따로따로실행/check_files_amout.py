import os
import time
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

file_total_amount = 30 * 1024**3 #30GB 가 기준입니다. 30GB가 넘어가면 자동으로 30% 이상 오래된 파일들을 순서로 삭제시킬 겁니다.
saved_videos_list = []
danger = 'danger_videos'
normal = 'normal_videos'
total = 0

list_lock = threading.Lock() #파일 삭제 시 오류 방지

def get_current_video_size():
    global total, saved_videos_list
    with list_lock:
        print("현재 총 용량 파악 중..")
        for i in [danger, normal]:
            for file_name in os.listdir(i):
                file_path = os.path.join(i, file_name)
                if os.path.isfile(file_path) and file_path.endswith('.avi'):
                    try:
                        file_size = os.path.getsize(file_path)
                        made_time = os.path.getatime(file_path)
                        saved_videos_list.append((file_path,file_size, made_time))
                        total += file_size
                    except (FileNotFoundError, OSError) as e:
                        print(f'{e}')
        saved_videos_list.sort(key = lambda x : x[2])
        print(f"계산 완료. 현재 총 용량 : {total / 1024**3:.2f}GB, 파일 개수 : {len(saved_videos_list)}")

               

def add_to_list(video_path):
    global total, saved_videos_list
    with list_lock:
        try:
            file_size = os.path.getsize(video_path)
            made_time = os.path.getatime(video_path)
            saved_videos_list.append((video_path, file_size, made_time))
            total += file_size
            saved_videos_list.sort(key = lambda x : x[2])
        except (FileNotFoundError, OSError) as e:
            print(f'{e}')


def check_all_amount_and_delete():
    global saved_videos_list, total
    print("총 저장된 영상 용량 확인 중..")
    print(f"현재 총 용량 : {total/1024**3:.2f}GB")
    with list_lock:
        if (total >= file_total_amount):
            print("자동 삭제를 시작합니다..")
            while(total > file_total_amount*0.7):
                file_path, file_size, _ = saved_videos_list[0]
                try:
                    os.remove(file_path)
                    total -= file_size
                    saved_videos_list.pop(0)
                except (FileNotFoundError, PermissionError, OSError) as e:
                    print(f"{e}")
                    total -= file_size
            print(f"자동 삭제 완료. 현재 총 파일 용량 : {total/1024**3:.2f} GB")
        else:
            print("자동 삭제 미실시.")

            


class VideoHandler(FileSystemEventHandler):
    def new_file(self, event):
        if not event.is_directory and event.src_path.endswith('.avi'):
            print(f"[!] 새 파일 감지: {event.src_path}")
            time.sleep(0.5)
            add_to_list(event.src_path)
            check_all_amount_and_delete()
            time.sleep(0.5)
            
if __name__ == "__main__":
    get_current_video_size()
    print("대기 중...")
    event_handler = VideoHandler()
    observer = Observer()
    observer.schedule(event_handler, danger, recursive=False)
    observer.schedule(event_handler, normal, recursive=False)
    observer.start()

    try:
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()